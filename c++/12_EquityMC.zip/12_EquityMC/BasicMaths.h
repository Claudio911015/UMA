#ifndef BASICMATHS_H
#define BASICMATHS_H

//standard normal CDF
double Ncdf(double x);

//standard normal PDF
double Npdf(double x);

#endif
