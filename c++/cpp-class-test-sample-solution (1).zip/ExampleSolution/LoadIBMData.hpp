#ifndef LOAD_IBM_DATA_HPP
#define LOAD_IBM_DATA_HPP

#include <vector>

std::vector<double> LoadIBMData();


#endif // LOAD_IBM_DATA_HPP

